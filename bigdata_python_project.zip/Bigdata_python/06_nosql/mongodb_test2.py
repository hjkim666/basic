# -*- coding: utf-8 -*-
import pymongo 
from pymongo import MongoClient
client = MongoClient()
client = MongoClient('localhost', 27017)
client = MongoClient('mongodb://localhost:27017/')
db = client.test_database
db = client['test']

post = {"author":"Mike","text":"my first blog post",
        "tags":["mongodb","python","pymongo"]}

posts = db.posts
post_id = posts.insert_one(post).inserted_id
print(post_id)
print(db.collection_names(include_system_collections=False))
print(posts.find_one())



post2 = {"author":"tom","text":"my test post",
        "tags":["mongodb","java","pymongo"]}

posts = db.posts
post_id = posts.insert_one(post2).inserted_id
print(post_id)
print(db.collection_names(include_system_collections=False))
print(posts.find_one({"_id":post_id}))

print(posts.find_one({"author":"tom"}))
print(posts.find_one({"author":"Mike"}))