def fn(a, b):
    print(a,b)
    
fn(*[1,2])    