class Student: # p351
    
    def __init__(self, name, hakbun):
        self.name = name
        self.hakbun = hakbun
    def show_info(self):
        s = "%s, %s" % (self.name,self.hakbun)
        return s