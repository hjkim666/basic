'''
PersonMain.py
인원관리 프로그램
객체 == 인스턴스
'''
from vo.person import Student
from manager.personManager import PersonManager
# import vo.person 
    
p = Student("홍길동",1101) #이름 학번
print( p.show_info() )

mgr = PersonManager()
mgr.add( p ) #학생 등록
print( mgr.count() )  #저장된 객체 갯수
p = Student("이순신",2210) #이름 학번
mgr.add( p ) 
print( mgr.count() )  #저장된 객체 갯수
mgr.print_all() #전체 출력
p = mgr.find(name="이순신")
if p==None:
    print("없는 자료입니다")
else:
    print("찾았음:",p.show_info())
     




