import pandas as pd 
import numpy as np 

data = {'state':['oh','oh','oh','Nev','Nev'],
        'year':[2000,2001,2002,2001,2002],
        'population':[1.5,1.7,2.3,2.9,3.2]
        }
# print(data)
# 
# frame = pd.DataFrame(data)
# print(frame)

frame = pd.DataFrame(data, columns=['year', 'state','population'])
print(frame[0:3])
print(frame['state'])
