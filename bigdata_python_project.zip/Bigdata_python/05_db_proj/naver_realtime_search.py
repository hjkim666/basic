
def save_db(rankdata):
    '''
    create table hotkeyword(
       id integer primary key autoincrement,
       rankinfo text);
    '''
    import sqlite3
    conn = sqlite3.connect("test.db")
    cur = conn.cursor()
    sql = "insert into hotkeyword(rankinfo) values (?)"
    cur.execute(sql, (rankdata,))
    conn.commit()
    conn.close()
def list_db():
    import sqlite3
    # SQLite DB 연결
    conn = sqlite3.connect("test.db")
    # Connection 으로부터 Cursor 생성
    cur = conn.cursor()
    # SQL 쿼리 실행
    cur.execute("select * from hotkeyword")
    # 데이타 Fetch
    rows = cur.fetchall()
    for row in rows:
        print(row)
    # Connection 닫기
    conn.close()

list_db()

# import urllib.request ,bs4 ,sys
# url = "http://www.naver.com"
# op = urllib.request.urlopen(url)
# txt = op.read()
# txt = txt.decode('utf-8')
# bs = bs4.BeautifulSoup(txt, "html.parser")
# naver_kw = bs.select("ul.ah_l")
#  
# if len(naver_kw)==0:
#     print("결과가 없읍니다.")
#     sys.exit()
# print("결과 갯수:",len(naver_kw))
#      
# kw_list = naver_kw[0].select("li")
# print( len(kw_list) )
# kw_list = naver_kw[1].select("li")
# print( len(kw_list) )
# kw_list = naver_kw[2].select("li")
# print( len(kw_list) )
# kw_list = naver_kw[0].select("li")
# # 검색어 추출
# rankinfo=""
# for item in kw_list:
#     kw = item.select(".ah_k")[0].string
#     rk = item.select(".ah_r")[0].string
#     print("검색어", kw,"등수",rk)
#     rankinfo += kw+":"+rk+","
#  
# print(rankinfo)
#  
#  
# save_db(rankinfo)
# print('저장완료!')