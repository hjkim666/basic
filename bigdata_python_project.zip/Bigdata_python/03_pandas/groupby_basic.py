import pandas as pd 
import numpy as np 

df = pd.DataFrame({'A':['foo','bar','foo','foo','bar'],
                   'B':np.random.randn(5)})
print(df)

result = df.groupby('A').sum()
print(result)