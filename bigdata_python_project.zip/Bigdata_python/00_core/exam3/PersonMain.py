from person import Student
    
p = Student("홍길동",1101) #이름 학번
print( p.show_info() )
 