class PersonManager(object):
    def __init__(self):
        self.plist = [] #객체 저장용 

    def add(self, p):
        self.plist.append(p)

    def count(self):
        return len( self.plist )
    
    def print_all(self):
        print("*** 전체 출력 ***")
        for p in self.plist:
            print(">>",p.show_info())

    def find(self, name):
        for p in self.plist:
            if p.name == name:
                return p
        return None
    
    
    





