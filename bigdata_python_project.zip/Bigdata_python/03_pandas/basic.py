import pandas as pd 
import numpy as np 

#series 
# object1 = pd.Series([4,5,-3,6])
# print(object1)

object2 = pd.Series([4,5,-3,6], index=['a','b','c','d'])
# print(object2)
# print(object2[['a','d']])

print(object2[object2 < 0])