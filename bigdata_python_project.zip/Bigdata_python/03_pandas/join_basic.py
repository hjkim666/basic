import pandas as pd 

left = pd.DataFrame({'key':['foo','bar'],
                     'lval':[1,2]})
print(left)

right = pd.DataFrame({'key':['foo','bar'],
                     'rval':[4,5]})
print(right)

result = pd.merge(left, right, on='key')
print(result)