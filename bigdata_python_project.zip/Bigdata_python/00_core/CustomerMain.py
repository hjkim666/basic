from Customer import Customer 

s = Customer("kim")
print(s.getName()) 
