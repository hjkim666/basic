class Person:
#     def __init__(self,name):
#         self.name = name

    def __init__(self,name,age):
        self.name = name
        self.age = age    
    def setName(self,name):
        self.name = name 
    def getName(self):
        return self.name
    def greet(self):
        print("Hello, I am %s "%self.name)


c1 = Person("kim",20)
print(c1.getName())   