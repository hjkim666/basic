import numpy as np 
# data = {i : np.random.randn() for i in range(7)}
# print

b = np.array([[1,2,3],[4,5,6]], dtype=np.int64)
print(b.dtype)

b1 = np.array([[1.,2.,3.],[4,5,6]])
print(b1.dtype)

# print(b)
# print(type(b))
# print(b.shape)
# print(b[0,0])

# c = np.arange(32).reshape(8,4)
# print(c)





