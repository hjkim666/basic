import urllib.request

url='http://www.google.com'
urllib.request.urlretrieve(url,'somefile.txt')