# -*- coding: utf-8 -*-
import pymongo 
from pymongo import MongoClient
client = MongoClient()
client = MongoClient('localhost', 27017)
client = MongoClient('mongodb://localhost:27017/')
db = client.test_database
db = client['test']
print(db.stud.find_one())