class Customer:
    def __init__(self,name):
        self.name = name
    def setName(self,name):
        self.name = name 
    def getName(self):
        return self.name
    
# c1 = Customer("kim")
# print(c1.getName())

            